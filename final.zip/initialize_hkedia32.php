<?php
if(isset($_GET['perm']) && $_GET['perm']==8746)
{

}
else{
	echo"you dont have permission to access this page";
}
?>