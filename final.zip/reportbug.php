<?php
if(isset($_POST['bugsubmit']))
{


	require_once "php/PHPMailerAutoload.php";

	$mail = new PHPMailer;

//Enable SMTP debugging. 
	$mail->SMTPDebug = 0;                               
//Set PHPMailer to use SMTP.
	$mail->isSMTP();            
//Set SMTP host name                          
	$mail->Host = "smtp.gmail.com";
//Set this to true if SMTP host requires authentication to send email
	$mail->SMTPAuth = true;                          
//Provide username and password     
	$mail->Username = "vitcabshare@gmail.com";                 
	$mail->Password = "harshitkediavitcabshare01";                           
//If SMTP requires TLS encryption then set it
	$mail->SMTPSecure = "tls";                           
//Set TCP port to connect to 
	$mail->Port = 587;                                   

	$mail->From = "vitcabshare@gmail.com";
	$mail->FromName = "VIT Cab share";

	$mail->addAddress("geek.harshitkedia@gmail.com", "Recepient Name");

	$mail->isHTML(true);


	$email = $_POST['email'];
	$message = $_POST['message'];
	$mail->Subject = "bug report in whoisfree";

	$mail->Body = "$email \n $message";
	$mail->AltBody = "This is the plain text version of the email content";

	if(!$mail->send()) 
	{
		echo "Mailer Error: " . $mail->ErrorInfo;
	} 
	else 
	{
		header('Location: thankyou.html');
		exit();
		echo "Message has been sent successfully";
		echo 'Boolean';
	}

}
else {


	?>
	<!DOCTYPE html>
	<html>
	<head>
		<title>Failed</title>
		<meta charset="UTF-8">
	</head>
	<body>
		<h3>You have not send a message</h3>
	</body>
	</html>
	<?php
}
?>