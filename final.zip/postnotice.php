<?php
if(isset($_POST['postsubmit']))
{
	$dbhost='mysql.hostinger.in';
	$dbuser='u638108590_acm';
	$dbpass='acmsecret';
	$dbname='u638108590_acm';
	$connection=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
	if(mysqli_connect_errno()){
		die("Database connection failed:".mysqli_connect_error());
	}
	$query="insert into notices (name,notice) values(";
	$name=$_POST['name'];
	$message=$_POST['message'];
	$query.="'$name'";
	$query.=",";
	$query.="'$message');";
	$result=mysqli_query($connection,$query);
	if(!($result)) echo "Failed to upload.";
	mysqli_close($connection);
	header("Location: user.php#notices");
}
else{
	echo"Error. data not submitted";
}
